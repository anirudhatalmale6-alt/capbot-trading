def profit_points(direction: str, entry_px: float, live_px: float) -> float:
    return (live_px - entry_px) if direction == "BUY" else (entry_px - live_px)

def maybe_trail_option_a(pos: dict, live_px: float, buffer_r: float) -> bool:
    """
    +1R => SL = BE + buffer
    +2R => SL = +1R + buffer
    Usa R_points guardado (entry->SL inicial). Nunca empeora.
    """
    direction = pos.get("direction")
    entry_px = float(pos.get("entry_price_est"))
    r_points = float(pos.get("r_points"))
    sl = float(pos.get("sl_local"))

    if r_points <= 0:
        return False

    ppts = profit_points(direction, entry_px, live_px)
    if ppts <= 0:
        return False

    buffer_pts = float(buffer_r) * r_points
    done_1r = bool(pos.get("trail_1r_done", False))
    done_2r = bool(pos.get("trail_2r_done", False))

    if direction == "BUY":
        sl_be = entry_px + buffer_pts
        sl_1r = entry_px + r_points + buffer_pts
        better = lambda new, old: new > old
    else:
        sl_be = entry_px - buffer_pts
        sl_1r = entry_px - r_points - buffer_pts
        better = lambda new, old: new < old

    changed = False

    if (not done_2r) and ppts >= 2.0 * r_points:
        if better(sl_1r, sl):
            pos["sl_local"] = float(sl_1r)
            changed = True
        pos["trail_2r_done"] = True
        pos["trail_1r_done"] = True

    if (not done_1r) and ppts >= 1.0 * r_points:
        cur = float(pos.get("sl_local"))
        if better(sl_be, cur):
            pos["sl_local"] = float(sl_be)
            changed = True
        pos["trail_1r_done"] = True

    return changed
