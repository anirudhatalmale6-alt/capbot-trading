import os
from pathlib import Path

class InstanceLock:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.fd = None

    def acquire(self) -> None:
        try:
            self.fd = os.open(str(self.path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
            os.write(self.fd, str(os.getpid()).encode("utf-8"))
            os.fsync(self.fd)
        except FileExistsError:
            raise RuntimeError(f"Lock activo: {self.path}. Ya hay otro proceso corriendo.")

    def release(self) -> None:
        try:
            if self.fd is not None:
                os.close(self.fd)
        finally:
            self.fd = None
            try:
                if self.path.exists():
                    self.path.unlink()
            except Exception:
                pass
