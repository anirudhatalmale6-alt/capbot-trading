import pytz
from dataclasses import dataclass
import pandas as pd

@dataclass(frozen=True)
class RTH:
    tz_name: str
    start_hh: int
    start_mm: int
    end_hh: int
    end_mm: int

    def in_rth(self, ts_utc: pd.Timestamp) -> bool:
        tz = pytz.timezone(self.tz_name)
        ts = ts_utc.tz_convert(tz)
        hh, mm = ts.hour, ts.minute
        start_ok = (hh > self.start_hh) or (hh == self.start_hh and mm >= self.start_mm)
        end_ok = (hh < self.end_hh) or (hh == self.end_hh and mm <= self.end_mm)
        return start_ok and end_ok
