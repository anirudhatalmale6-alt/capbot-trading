import csv
from pathlib import Path
from typing import Any, Dict

HEADER = [
    "entry_time","exit_time","direction","size",
    "entry_price_est","entry_price_api","exit_price_est","exit_price_api",
    "profit_api","profit_ccy",
    "r_points","initial_sl","sl_local","tp_local",
    "exit_reason","position_deal_id","close_dealReference",
    "meta_json"
]

def ensure_header(csv_path: Path) -> None:
    csv_path = Path(csv_path)
    if csv_path.exists():
        return
    csv_path.parent.mkdir(parents=True, exist_ok=True)
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerow(HEADER)

def append_row(csv_path: Path, row: Dict[str, Any]) -> None:
    with open(csv_path, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow([row.get(h) for h in HEADER])
