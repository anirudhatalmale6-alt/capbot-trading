import os
import time
import re
from typing import Any, Dict, Optional

import pandas as pd

from capbot.app.notifier import email_event, email_startup
from capbot.broker.capital_client import CapitalClient, pick_position_dealid_from_confirm
from capbot.data.prices import prices_to_df
from capbot.domain.lock import InstanceLock
from capbot.domain.logger import log_line
from capbot.domain.paths import bot_paths
from capbot.domain.risk import calc_position_size
from capbot.domain.schedule import RTH
from capbot.domain.state_store import load_state, save_state_atomic
from capbot.domain.trade_log import append_row, ensure_header
from capbot.domain.trailing import maybe_trail_option_a
from capbot.strategies.loader import load_strategy


def _expand_env(s: Any) -> Any:
    """Expande strings tipo '${VAR}' usando os.environ.
    Si no existe VAR, deja el literal intacto.
    """
    if not isinstance(s, str):
        return s
    m = re.fullmatch(r"\$\{([A-Z0-9_]+)\}", s.strip())
    if not m:
        return s
    return os.environ.get(m.group(1), s)


def utc_now() -> pd.Timestamp:
    return pd.Timestamp.now(tz="UTC")


def _as_ts(x: Optional[str]) -> Optional[pd.Timestamp]:
    if not x:
        return None
    try:
        return pd.to_datetime(x, utc=True)
    except Exception:
        return None


def _resolution_to_minutes(resolution: str) -> int:
    r = (resolution or "").upper().strip()
    if r.startswith("MINUTE_"):
        try:
            return int(r.split("_", 1)[1])
        except Exception:
            return 5
    if r in ("HOUR", "HOUR_1"):
        return 60
    if r == "HOUR_4":
        return 240
    if r == "DAY":
        return 1440
    return 5


def _rth_is_open(rth: RTH, ts: pd.Timestamp) -> bool:
    fn = getattr(rth, "is_open", None)
    if callable(fn):
        return bool(fn(ts))

    # fallback manual
    import pytz
    tz = pytz.timezone(getattr(rth, "tz_name", "UTC"))
    local = ts.tz_convert(tz)
    if local.weekday() >= 5:
        return False
    sh = int(getattr(rth, "start_hh", 0))
    sm = int(getattr(rth, "start_mm", 0))
    eh = int(getattr(rth, "end_hh", 23))
    em = int(getattr(rth, "end_mm", 59))
    start = local.replace(hour=sh, minute=sm, second=0, microsecond=0)
    end = local.replace(hour=eh, minute=em, second=0, microsecond=0)
    return start <= local <= end


def run_bot(cfg: Dict[str, Any], once: bool = False):
    bot_id = str(cfg.get("bot_id") or (cfg.get("market") or {}).get("epic") or "capbot")

    state_path, csv_path, logfile, lock_path = bot_paths(bot_id)
    # --- DEBUG: confirm log target + env presence (do NOT print secrets) ---
    try:
        log_line(logfile, f"BOOT sp500_rth bot_id={bot_id} state={state_path.name} trades={csv_path.name}")
        log_line(logfile, "ENV " + " ".join([
            f"CAPITAL_ENV={os.getenv('CAPITAL_ENV','')}",
            f"CAPITAL_API_KEY={'SET' if os.getenv('CAPITAL_API_KEY') else 'MISSING'}",
            f"CAPITAL_ACCOUNT_ID={'SET' if os.getenv('CAPITAL_ACCOUNT_ID') else 'MISSING'}",
        ]))
    except Exception as _e:
        # If logging fails, we still want the bot to continue
        pass


    try:
        lock = InstanceLock(lock_path, 1800)
    except TypeError:
        lock = InstanceLock(lock_path)

    def save_state(st: dict):
        save_state_atomic(state_path, st)

    lock.acquire()
    try:
        ensure_header(csv_path)
        st = load_state(state_path) or {}
    except Exception:
        pass

        poll = int(cfg.get("poll_seconds", 30))

        # ---- Market / data ----
        market = cfg.get("market") or {}
        epic = str(market.get("epic") or "").strip()
        resolution = str(market.get("resolution") or "MINUTE_5").strip()
        warmup = int(market.get("warmup_bars", 200))
        if not epic:
            raise RuntimeError("Config error: market.epic is missing")

        bar_minutes = _resolution_to_minutes(resolution)

        # ---- Schedule ----
        schedule_cfg = cfg.get("schedule") or {}
        tz_name = str(schedule_cfg.get("timezone", "America/New_York"))
        rth_enabled = bool(schedule_cfg.get("rth_enabled", True))
        disable_thursday_utc = bool(schedule_cfg.get("disable_thursday_utc", True))

        rth_start = str(schedule_cfg.get("rth_start", "09:30"))
        rth_end = str(schedule_cfg.get("rth_end", "16:00"))

        rth = RTH(
            tz_name=tz_name,
            start_hh=int(rth_start.split(":")[0]),
            start_mm=int(rth_start.split(":")[1]),
            end_hh=int(rth_end.split(":")[0]),
            end_mm=int(rth_end.split(":")[1]),
        )

        # ---- Risk ----
        risk_cfg = cfg.get("risk") or {}
        bot_equity = float(risk_cfg.get("bot_equity", 25000.0))
        risk_pct = float(risk_cfg.get("risk_pct", 0.02))
        vpp = float(risk_cfg.get("value_per_point_per_size", 1.0))
        exit_bars = int(risk_cfg.get("exit_bars", 24))

        # ---- Trailing ----
        trailing_cfg = cfg.get("trailing") or {}
        trailing_on = bool(trailing_cfg.get("enabled", True))
        trail_buffer_r = float(trailing_cfg.get("buffer_r", 0.10))

        # ---- Circuit breaker ----
        cb_cfg = cfg.get("circuit_breaker") or {}
        cb_losses = int(cb_cfg.get("losses", 3))
        cb_cooldown = int(cb_cfg.get("cooldown_min", 60))

        # ---- Notifications ----
        notif_cfg = cfg.get("notifications") or {}
        email_enabled = bool(notif_cfg.get("email_enabled", True))

        # ---- Strategy ----
        strategy_cfg = cfg.get("strategy") or {}
        strat = load_strategy(strategy_cfg.get("module"))
        strat_params = strategy_cfg.get("params") or {}

        # ---- Account selection ----
        account_cfg = cfg.get("account") or {}
        account_id = account_cfg.get("account_id") or os.environ.get("CAPITAL_ACCOUNT_ID")
        account_id = _expand_env(account_id)

        client = CapitalClient()
        email_startup(email_enabled, bot_id, cfg, logfile)

        # --- Startup smoke test: BUY -> wait -> CLOSE (configurable) ---
        startup_cfg = cfg.get("startup_smoke_test") or {}
        if bool(startup_cfg.get("enabled", False)):
            try:
                force_demo_only = bool(startup_cfg.get("force_demo_only", True))
                cap_env = (os.getenv("CAPITAL_ENV") or "").strip().lower()
            except Exception:
                pass

                if force_demo_only and cap_env != "demo":
                    log_line(logfile, f"SMOKE_TEST SKIP (CAPITAL_ENV={cap_env}, force_demo_only=true)")
                else:
                    epic_smoke = (startup_cfg.get("epic") or (cfg.get("market") or {}).get("epic"))
                    direction_smoke = str(startup_cfg.get("direction", "BUY")).upper().strip()
                    size_smoke = float(startup_cfg.get("size", 0.1))
                    sleep_smoke = int(startup_cfg.get("sleep_seconds", 5))

                    if not epic_smoke:
                        raise RuntimeError("SMOKE_TEST: missing epic (set market.epic or startup_smoke_test.epic)")

                    # --- SMOKE TEST: best-effort skip if outside RTH (if helpers exist) ---
                    try:
                        now_smoke = utc_now()
                        if rth_enabled:
                            ok = _rth_is_open(rth, now_smoke)
                            if not ok:
                                log_line(logfile, f"GATE: outside RTH ({rth_start}-{rth_end} {schedule_cfg.get('timezone','Europe/Berlin')})")
                                raise RuntimeError("SMOKE_TEST_SKIPPED_OUTSIDE_RTH")
                    except Exception:
                        pass

                    # Ensure session + correct account before smoke trade
                    client.login()
                    client.ensure_account(account_id)
                    try:
                        sess_dbg = client.get_session() or {}
                        cur_dbg = sess_dbg.get("currentAccountId") or sess_dbg.get("accountId")
                        log_line(logfile, f"SMOKE_TEST SESSION account_id={cur_dbg} expected={account_id}")
                        if account_id and str(cur_dbg) != str(account_id):
                            log_line(logfile, f"ACCOUNT_MISMATCH expected={account_id} got={cur_dbg} (aborting smoke)")
                            raise RuntimeError("ACCOUNT_MISMATCH")
                    except Exception as _e:
                        log_line(logfile, f"SMOKE_TEST SESSION check failed: {repr(_e)}")
                        raise

                    resp = client.open_market(epic=epic_smoke, direction=direction_smoke, size=size_smoke)

                    deal_ref = (resp or {}).get("dealReference") or (resp or {}).get("deal_reference")
                    if not deal_ref:
                        raise RuntimeError(f"SMOKE_TEST: open_market() no dealReference: {resp}")

                    conf = client.confirm(deal_ref, timeout_sec=30) or {}
                    deal_id = pick_position_dealid_from_confirm(conf)
                    if not deal_id:
                        raise RuntimeError(f"SMOKE_TEST: confirm() no dealId: {conf}")

                    log_line(logfile, f"SMOKE_TEST OPEN deal_id={deal_id} dir={direction_smoke} size={size_smoke}")
                    email_event(email_enabled, bot_id, "SMOKE_TEST_OPENED", {
                        "deal_id": deal_id,
                        "epic": epic_smoke,
                        "direction": direction_smoke,
                        "size": size_smoke
                    }, logfile)

                    time.sleep(sleep_smoke)

                    close_resp = client.close_position(deal_id)

                    log_line(logfile, f"SMOKE_TEST CLOSE deal_id={deal_id} resp={str(close_resp)[:250]}")
                    email_event(email_enabled, bot_id, "SMOKE_TEST_CLOSED", {
                        "deal_id": deal_id,
                        "sleep_seconds": sleep_smoke
                    }, logfile)

            except Exception as e:
                log_line(logfile, f"SMOKE_TEST ERROR: {repr(e)}")
                email_event(email_enabled, bot_id, "SMOKE_TEST_ERROR", {"error": repr(e)}, logfile)


        last_closed_time = _as_ts(st.get("last_closed_time"))

        while True:
            now = utc_now()

            # --- SP500 RTH-only hard gate (NY 09:30-16:00). No transitions outside session. ---
            if rth_enabled:
                try:
                    if not _rth_is_open(rth, now):
                        try:
                            log_line(logfile, f"GATE_SP500: outside RTH ({rth_start}-{rth_end} {tz_name}) now_utc={now}")
                        except Exception:
                            pass
                        # Para SP500: no cortamos aquí (queremos que llegue al gate inferior que imprime VIS).
                        # Seguimos bloqueando entradas igualmente, solo permitimos VIS/debug.
                        if str(bot_id) not in ("sp500_5m", "sp500_5m_rth"):
                            if once:
                                return
                            time.sleep(poll)
                            continue
                except Exception:
                    pass

            # ---- Heartbeat diario al abrir RTH (Berlin) ----
            try:
                now_local = now.tz_convert(tz_name)
                if now_local.weekday() < 5:
                    sh, sm = map(int, rth_start.split(":"))
                    if now_local.hour == sh and now_local.minute == sm:
                        sent_date = st.get("heartbeat_sent_date")
                        today = now_local.date().isoformat()
                        if sent_date != today:
                            email_event(email_enabled, bot_id, "HEARTBEAT_RTH_OPEN", {
                                "time_local": now_local.isoformat(),
                                "timezone": tz_name,
                                "account_id": account_id,
                                "epic": epic,
                                "poll_seconds": poll,
                            }, logfile)
                            st["heartbeat_sent_date"] = today
                            save_state(st)
            except Exception as e:
                log_line(logfile, f"HEARTBEAT warning: {repr(e)}")

            # Ensure session + correct account
            client.login()
            client.ensure_account(account_id)
            try:
                sess_dbg = client.get_session() or {}
                cur_dbg = sess_dbg.get("currentAccountId") or sess_dbg.get("accountId")
                if account_id and str(cur_dbg) != str(account_id):
                    log_line(logfile, f"ACCOUNT_MISMATCH expected={account_id} got={cur_dbg} (skipping cycle)")
                    time.sleep(poll)
                    continue
            except Exception as _e:
                log_line(logfile, f"ACCOUNT check warning: {repr(_e)}")

            pos = st.get("pos") or {}
            deal_id = pos.get("deal_id")
            in_position = bool(deal_id)

            # ===========================
            # 9) Gestión si hay posición
            # ===========================
            if in_position:
                # SP500_SPEC_FINAL_V1 --- gestión EXACTA según spec del usuario (SP500 5m) ---
                if str(bot_id) in ("sp500_5m_rth","sp500_5m"):
                    # 1) Cargar velas (solo cerradas)
                    px = client.get_prices(epic, resolution, max_points=max(warmup, 200))
                    df = prices_to_df(px)
                    if df is None or df.empty or len(df) < 3:
                        log_line(logfile, "WARN: no prices returned")
                        if once: return
                        time.sleep(poll)
                        continue

                    # determinista: siempre vela cerrada
                    bar_t = df.index[-2]
                    last_mgmt = st.get("last_mgmt_bar_iso")
                    if last_mgmt and str(last_mgmt) == str(bar_t.isoformat()):
                        if once: return
                        time.sleep(poll)
                        continue
                    st["last_mgmt_bar_iso"] = bar_t.isoformat()
                    save_state(st)

                    bar = df.iloc[-2]
                    close_px = float(bar["close"])
                    bar_high = float(bar["high"])
                    bar_low  = float(bar["low"])

                    pos = st.get("pos") or {}
                    deal_id = pos.get("deal_id")
                    if not deal_id:
                        if once: return
                        time.sleep(poll)
                        continue

                    direction = str(pos.get("direction","")).upper()
                    entry_price = float(pos.get("entry_price_est"))
                    atr_entry = float(pos.get("atr_entry") or 0.0)
                    if atr_entry <= 0:
                        # fallback seguro: no gestionamos si falta ATR
                        log_line(logfile, "WARN: SP500 missing atr_entry in state")
                        if once: return
                        time.sleep(poll)
                        continue

                    entry_time = _as_ts(pos.get("entry_time_iso") or pos.get("entry_time_iso_compat") or pos.get("entry_time"))
                    if entry_time is None:
                        # fallback: no gestionamos si falta entry_time
                        log_line(logfile, "WARN: SP500 missing entry_time in state")
                        if once: return
                        time.sleep(poll)
                        continue

                    # Spec: gestión empieza en velas posteriores a la entrada (k = i+1 ...)
                    if bar_t <= entry_time:
                        if once: return
                        time.sleep(poll)
                        continue

                    sl_local = float(pos.get("sl_local"))
                    tp_local = float(pos.get("tp_local"))
                    be_armed = bool(pos.get("be_armed", False))

                    # ========= 9.1 SALIDA PRIMERO (TP-first) usando SL vigente de vela anterior =========
                    hit_tp = False
                    hit_sl = False

                    if direction == "BUY":
                        hit_tp = (bar_high >= tp_local)
                        if not hit_tp:
                            hit_sl = (bar_low <= sl_local)
                    else:
                        hit_tp = (bar_low <= tp_local)
                        if not hit_tp:
                            hit_sl = (bar_high >= sl_local)

                    if hit_tp or hit_sl:
                        if hit_tp:
                            reason = "EXIT_TP"
                            exit_price = float(tp_local)
                        else:
                            reason = "EXIT_SL"
                            exit_price = float(sl_local)

                        conf = client.close_position(str(deal_id))
                        append_row(csv_path, bar_t.isoformat(), bot_id, epic, direction, pos.get("size"), reason, exit_price, conf)

                        st["pos"] = {}
                        st["last_closed_time"] = bar_t.isoformat()
                        save_state(st)
                        # (emails: si quieres solo STARTED, aquí puedes desactivar)
                        email_event(email_enabled, bot_id, reason, {"deal_id": deal_id, "exit_price": exit_price}, logfile)

                        if once: return
                        time.sleep(poll)
                        continue

                    # ========= 9.2 UPDATE END-OF-BAR (trailing + BE lock) =========
                    if direction == "BUY":
                        max_fav = float(pos.get("max_fav", entry_price))
                        max_fav = max(max_fav, bar_high)
                        if bar_high > entry_price:
                            be_armed = True
                        slcand = max_fav - 1.0 * atr_entry
                        sl_local = max(sl_local, slcand)  # nunca baja
                        if be_armed:
                            sl_local = max(sl_local, entry_price)  # nunca por debajo de entrada
                        pos["max_fav"] = float(max_fav)
                    else:
                        min_fav = float(pos.get("min_fav", entry_price))
                        min_fav = min(min_fav, bar_low)
                        if bar_low < entry_price:
                            be_armed = True
                        slcand = min_fav + 1.0 * atr_entry
                        sl_local = min(sl_local, slcand)  # nunca sube
                        if be_armed:
                            sl_local = min(sl_local, entry_price)  # nunca por encima de entrada
                        pos["min_fav"] = float(min_fav)

                    pos["be_armed"] = bool(be_armed)
                    pos["sl_local"] = float(sl_local)
                    # TP permanece constante en tu spec
                    pos["tp_local"] = float(tp_local)

                    # contador de velas completas desde entrada (k = i+1 => 1)
                    bars = int(pos.get("bars_since_entry", 0))
                    bars += 1
                    pos["bars_since_entry"] = int(bars)

                    st["pos"] = pos
                    save_state(st)

                    # ========= 10) TIME-EXIT (24 velas completas) =========
                    # se evalúa DESPUÉS de TP/SL de esta vela; si sigue vivo, cerramos en CLOSE de la #24
                    if bars >= 24:
                        reason = "TIME_EXIT"
                        exit_price = float(close_px)
                        conf = client.close_position(str(deal_id))
                        append_row(csv_path, bar_t.isoformat(), bot_id, epic, direction, pos.get("size"), reason, exit_price, conf)

                        st["pos"] = {}
                        st["last_closed_time"] = bar_t.isoformat()
                        save_state(st)
                        email_event(email_enabled, bot_id, reason, {"deal_id": deal_id, "exit_price": exit_price}, logfile)

                        if once: return
                        time.sleep(poll)
                        continue

                    # sigue vivo
                    if once: return
                    time.sleep(poll)
                    continue
                # SP500_SPEC_FINAL_V1 --- fin gestión SP500 ---

                px = client.get_prices(epic, resolution, max_points=max(warmup, 200))
                df = prices_to_df(px)
                if df is None or df.empty or len(df) < 3:
                    log_line(logfile, "WARN: no prices returned")
                    if once:
                        return
                    time.sleep(poll)
                    continue

                # Siempre con la vela cerrada (determinista)
                bar_t = df.index[-2]
                last_mgmt = st.get("last_mgmt_bar_iso")
                if last_mgmt and str(last_mgmt) == str(bar_t.isoformat()):
                    if once:
                        return
                    time.sleep(poll)
                    continue

                st["last_mgmt_bar_iso"] = bar_t.isoformat()
                save_state(st)

                bar = df.iloc[-2]
                close_px = float(bar["close"])
                bar_high = float(bar["high"])
                bar_low = float(bar["low"])

                direction = str(pos.get("direction")).upper()

                # 1) OUTSIDE_RTH (Berlin): cerrar a mercado.
                if rth_enabled and (not _rth_is_open(rth, sig_ts_utc)):
                    exit_price = close_px  # convención: close de la vela cerrada
                    conf = client.close_position(str(deal_id))
                    append_row(csv_path, now.isoformat(), bot_id, epic, direction, pos.get("size"), "EXIT_RTH", exit_price, conf)

                    # Circuit breaker LOCAL al cerrar
                    try:
                        entry_price = float(pos.get("entry_price_est"))
                        size_pos = float(pos.get("size"))
                        profit_points = (exit_price - entry_price) if direction == "BUY" else (entry_price - exit_price)
                        profit_cash = profit_points * size_pos * vpp
                        consec = int(st.get("consec_losses", 0))
                        consec = (consec + 1) if profit_cash < 0 else 0
                        st["consec_losses"] = consec
                        if consec >= cb_losses:
                            st["cooldown_until_iso"] = (now + pd.Timedelta(minutes=cb_cooldown)).isoformat()
                    except Exception:
                        pass

                    st["pos"] = {}
                    st["last_closed_time"] = now.isoformat()
                    save_state(st)
                    email_event(email_enabled, bot_id, "EXIT_RTH", {"deal_id": deal_id, "exit_price": exit_price}, logfile)

                    if once:
                        return
                    time.sleep(poll)
                    continue

                

                if str(bot_id) != "sp500_5m":


                    # 2) TIME_EXIT (2h desde entry_time)


                                    planned_exit = _as_ts(pos.get("planned_exit_iso"))


                                    if planned_exit and now >= planned_exit:


                                        exit_price = close_px


                                        conf = client.close_position(str(deal_id))


                                        append_row(csv_path, now.isoformat(), bot_id, epic, direction, pos.get("size"), "EXIT_TIME", exit_price, conf)



                                        try:


                                            entry_price = float(pos.get("entry_price_est"))


                                            size_pos = float(pos.get("size"))


                                            profit_points = (exit_price - entry_price) if direction == "BUY" else (entry_price - exit_price)


                                            profit_cash = profit_points * size_pos * vpp


                                            consec = int(st.get("consec_losses", 0))


                                            consec = (consec + 1) if profit_cash < 0 else 0


                                            st["consec_losses"] = consec


                                            if consec >= cb_losses:
                                                pass


                                            st["cooldown_until_iso"] = (now + pd.Timedelta(minutes=cb_cooldown)).isoformat()


                                        except Exception:
                                            pass
                                        except Exception:


                                            pass



                                        st["pos"] = {}


                                        st["last_closed_time"] = now.isoformat()


                                        save_state(st)


                                        email_event(email_enabled, bot_id, "EXIT_TIME", {"deal_id": deal_id, "exit_price": exit_price}, logfile)



                                        if once:


                                            return


                                        time.sleep(poll)


                                        continue

                # 3/4) STOP/TP con high/low (STOP primero si ambos)
                sl_local = float(pos.get("sl_local"))
                tp_local = float(pos.get("tp_local"))

                hit_sl = (direction == "BUY" and bar_low <= sl_local) or (direction == "SELL" and bar_high >= sl_local)
                hit_tp = (direction == "BUY" and bar_high >= tp_local) or (direction == "SELL" and bar_low <= tp_local)

                if hit_sl or hit_tp:
                    if hit_sl:
                        reason = "EXIT_SL"
                        exit_price = float(sl_local)
                    else:
                        reason = "EXIT_TP"
                        exit_price = float(tp_local)

                    conf = client.close_position(str(deal_id))
                    append_row(csv_path, now.isoformat(), bot_id, epic, direction, pos.get("size"), reason, exit_price, conf)

                    # Circuit breaker LOCAL
                    try:
                        entry_price = float(pos.get("entry_price_est"))
                        size_pos = float(pos.get("size"))
                        profit_points = (exit_price - entry_price) if direction == "BUY" else (entry_price - exit_price)
                        profit_cash = profit_points * size_pos * vpp
                        consec = int(st.get("consec_losses", 0))
                        consec = (consec + 1) if profit_cash < 0 else 0
                        st["consec_losses"] = consec
                        if consec >= cb_losses:
                            st["cooldown_until_iso"] = (now + pd.Timedelta(minutes=cb_cooldown)).isoformat()
                    except Exception:
                        pass

                    st["pos"] = {}
                    st["last_closed_time"] = now.isoformat()
                    save_state(st)
                    email_event(email_enabled, bot_id, reason, {"deal_id": deal_id, "exit_price": exit_price}, logfile)

                    if once:
                        return
                    time.sleep(poll)
                    continue

                # 8) Trailing SL (solo mejora, al cierre)
                if trailing_on:
                    try:
                        moved, new_sl, flags = maybe_trail_option_a(
                            direction=direction,
                            entry=float(pos.get("entry_price_est")),
                            live=float(close_px),
                            r_points=float(pos.get("r_points")),
                            current_sl=float(pos.get("sl_local")),
                            trail_1r_done=bool(pos.get("trail_1r_done")),
                            trail_2r_done=bool(pos.get("trail_2r_done")),
                            buffer_r=float(trail_buffer_r),
                        )
                        if moved:
                            pos["sl_local"] = float(new_sl)
                            pos["trail_1r_done"] = bool(flags.get("trail_1r_done"))
                            pos["trail_2r_done"] = bool(flags.get("trail_2r_done"))
                            st["pos"] = pos
                            save_state(st)
                            email_event(email_enabled, bot_id, "TRAIL_SL", {"deal_id": deal_id, "sl_local": new_sl}, logfile)
                    except Exception as e:
                        log_line(logfile, f"TRAIL warning: {repr(e)}")

                if once:
                    return
                time.sleep(poll)
                continue

            # =======================
            # 4) Gates de entradas
            # =======================
            # --- SP500: gates evaluados con timestamp de la vela señal (df.index[-2]) ---
            sig_ts = now
            if str(bot_id) in ("sp500_5m","sp500_5m_rth"):
                try:
                    px_sig = client.get_prices(epic, resolution, max_points=max(warmup, 200))
                    df_sig = prices_to_df(px_sig)
                    if df_sig is not None and (not df_sig.empty) and len(df_sig) >= 2:
                        sig_ts = df_sig.index[-2]
                except Exception:
                    sig_ts = now
            # 1) No operar jueves UTC
            # SP500_SIG_TS_SAFE_V1_START
            import pandas as pd
            _x = sig_ts
            if isinstance(_x, (int, float)):
                v = int(_x)
                unit = 'ms' if v > 10**11 else 's'
                _x = pd.to_datetime(v, unit=unit, utc=True, errors='coerce')
            else:
                _x = pd.to_datetime(_x, utc=True, errors='coerce')
            if _x is pd.NaT:
                _x = pd.Timestamp.now(tz='UTC')
            sig_ts_utc = _x
            # Guard: si el timestamp viene como int pequeño y cae en 1970, usa now UTC
            try:
                if getattr(sig_ts_utc, 'year', 1970) < 2000:
                    sig_ts_utc = pd.Timestamp.now(tz='UTC')
            except Exception:
                sig_ts_utc = pd.Timestamp.now(tz='UTC')
            # SP500_SIG_TS_SAFE_V1_END
                # VIS_ALWAYS_3LINES_SP500_OUTSIDE_RTH_V1_START
                # VIS limpio (SP500) — imprime 3 líneas por ciclo aunque esté fuera de RTH
                try:
                    if str(bot_id) in ("sp500_5m","sp500_5m_rth"):
                        import pandas as pd
                        OK="✅"; NO="❌"
                        def ok(x): return OK if x else NO
                
                        # Datos frescos
                        px_vis = client.get_prices(epic, resolution, max_points=max(warmup, 200))
                        df_vis = prices_to_df(px_vis)
                        if df_vis is None or getattr(df_vis, "empty", True) or len(df_vis) < 25:
                            log_line(logfile, "VIS_NY | sigNY=NA | THU ? | RTH ? | VALID ❌ | BODY ❌(nan>=0.70) | VOL ❌(nan>=0.70) | RSI nan | ATR nan")
                            log_line(logfile, "LONG=❌ SHORT=❌ | bear3=None bull3=None |")
                            log_line(logfile, "ENTRY ❌")
                        else:
                            # Vela señal = cerrada
                            ts = df_vis.index[-2]
                            ts_utc = pd.to_datetime(ts, utc=True, errors="coerce")
                            if ts_utc is pd.NaT or getattr(ts_utc, "year", 1970) < 2000:
                                ts_utc = pd.Timestamp.now(tz="UTC")
                
                            # Gates según SPEC
                            g_thu = not (bool(disable_thursday_utc) and (ts_utc.weekday() == 3))
                            try:
                                g_rth = (not bool(rth_enabled)) or _rth_is_open(rth, ts_utc)
                            except Exception:
                                g_rth = False
                            # Row vela señal
                            row = df_vis.iloc[-2]
                            o = float(row.get("open"))
                            h = float(row.get("high"))
                            l = float(row.get("low"))
                            c = float(row.get("close"))
                            v = float(row.get("volume"))
                
                            rng = (h - l)
                            valid = (rng > 0)
                            body_ratio = abs(c - o) / rng if valid else float("nan")
                            body_ok = (valid and body_ratio >= 0.70)
                
                            vol_ma20 = df_vis["volume"].rolling(20).mean().iloc[-2]
                            vol_ok = (pd.notna(v) and pd.notna(vol_ma20) and vol_ma20 != 0 and (v / vol_ma20) >= 0.70)
                            vol_rel = (v / vol_ma20) if (pd.notna(v) and pd.notna(vol_ma20) and vol_ma20 != 0) else float("nan")
                
                            close = df_vis["close"]
                            delta = close.diff()
                            up = delta.clip(lower=0).rolling(14).mean()
                            down = (-delta.clip(upper=0)).rolling(14).mean()
                            rsi = float("nan")
                            if pd.notna(down.iloc[-2]) and down.iloc[-2] != 0 and pd.notna(up.iloc[-2]):
                                rs = up.iloc[-2] / down.iloc[-2]
                                rsi = 100 - 100/(1+rs)
                
                            prev_close = close.shift(1)
                            tr = (df_vis["high"] - df_vis["low"]).to_frame("a")
                            tr["b"] = (df_vis["high"] - prev_close).abs()
                            tr["c"] = (df_vis["low"] - prev_close).abs()
                            atr = tr.max(axis=1).rolling(14).mean().iloc[-2]
                
                            # prev3 excluye vela señal
                            sub = df_vis.iloc[-5:-2]  # i-3,i-2,i-1
                            bear3 = float((sub["close"] < sub["open"]).sum()) if len(sub) == 3 else None
                            bull3 = float((sub["close"] > sub["open"]).sum()) if len(sub) == 3 else None
                
                            # Condiciones entrada
                            long_ok = False
                            short_ok = False
                            entry_ok = False
                            if g_thu and g_rth and body_ok and vol_ok and pd.notna(rsi) and pd.notna(atr) and bear3 is not None and bull3 is not None:
                                long_ok  = (c > o) and (bear3 >= 2) and (rsi < 75)
                                short_ok = (c < o) and (bull3 >= 2) and (rsi > 40)
                                entry_ok = bool(long_ok or short_ok)
                
                            ts_ny = ts_utc.tz_convert("America/New_York")
                            ny_str = ts_ny.strftime("%Y-%m-%d %H:%M")
                
                            bv = "nan" if body_ratio != body_ratio else f"{body_ratio:.3f}"
                            vv = "nan" if vol_rel != vol_rel else f"{vol_rel:.3f}"
                            rv = "nan" if rsi != rsi else f"{rsi:.2f}"
                            av = "nan" if atr != atr else f"{float(atr):.2f}"
                
                            log_line(logfile, f"VIS_NY | sigNY={ny_str} | THU {ok(g_thu)} | RTH {ok(g_rth)} | VALID {ok(valid)} | BODY {ok(body_ok)}({bv}>=0.70) | VOL {ok(vol_ok)}({vv}>=0.70) | RSI {rv} | ATR {av}")
                            log_line(logfile, f"LONG={ok(long_ok)} SHORT={ok(short_ok)} | bear3={bear3} bull3={bull3} |")
                            log_line(logfile, f"ENTRY {ok(entry_ok)}")
                except Exception as _e:
                    log_line(logfile, f"VIS_ERR_SP500: {repr(_e)}")
                # VIS_ALWAYS_3LINES_SP500_OUTSIDE_RTH_V1_END

                pass  # disabled legacy VIS_SP500_PRE_RTH

                if once:
                    return
                time.sleep(poll)
                continue

            # 3) NO_TRADE_HOURS gate REMOVED

            # 8) Circuit breaker (solo bloquea si flat)
            cooldown_until = _as_ts(st.get("cooldown_until_iso"))
            if cooldown_until and now < cooldown_until:
                log_line(logfile, f"GATE: circuit breaker cooldown until {cooldown_until.isoformat()}")
                if once:
                    return
                time.sleep(poll)
                continue

            # =======================
            # 2) Señal en vela cerrada
            # =======================
            px = client.get_prices(epic, resolution, max_points=max(warmup, 200))
            df = prices_to_df(px)
            if df is None or df.empty or len(df) < 3:
                log_line(logfile, "WARN: no prices returned")
                if once:
                    return
                time.sleep(poll)
                continue

            df = strat.enrich(df, strat_params)
            # SP500 strategy adapter: algunos strategies solo exponen signal_on_row

            if hasattr(strat, 'signal_on_bar_close'):

                sig = strat.signal_on_bar_close(df, strat_params)

            elif hasattr(strat, 'signal_on_row'):

                sig = strat.signal_on_row(df, strat_params)

            else:

                raise AttributeError('Strategy missing signal method (need signal_on_bar_close or signal_on_row)')
            # VIS_ALWAYS_3LINES_GERMANY40_V1_START
            try:
                # Solo Germany40
                if str(locals().get("bot_id", "")) == "germany40_5m_vwap":
                    OK = "\u2705"
                    NO = "\u274c"
                    def ok(x): return OK if x else NO
                    import math

                    _row = df.iloc[-2] if len(df) >= 2 else df.iloc[-1]

                    o = float(_row.get("open", float("nan")))
                    c = float(_row.get("close", float("nan")))
                    body = float(_row.get("body_ratio", float("nan")))
                    volr = float(_row.get("vol_rel", float("nan")))
                    rsi  = float(_row.get("rsi14", float("nan")))
                    atr  = float(_row.get("atr14", float("nan")))
                    vwap = float(_row.get("vwap", float("nan")))
                    bear3 = _row.get("bear_prev3", None)
                    bull3 = _row.get("bull_prev3", None)

                    p_ = (strat_params or {})
                    BODY_MIN      = float(p_.get("BODY_MIN", 0.70))
                    VOL_REL_MIN   = float(p_.get("VOL_REL_MIN", 0.70))
                    RSI_LONG_MAX  = float(p_.get("RSI_LONG_MAX", 75.0))
                    RSI_SHORT_MIN = float(p_.get("RSI_SHORT_MIN", 40.0))
                    BEAR3_LONG    = float(p_.get("BEAR_PREV3_LONG", 2))
                    BULL3_SHORT   = float(p_.get("BULL_PREV3_SHORT", 2))
                    VWAP_K        = float(p_.get("VWAP_DISTANCE_K", 0.20))

                    def _isnum(x):
                        try:
                            return (x == x) and (not math.isinf(x))
                            return False

                    # Gates (siempre calculados aquí)
                    g_thu = not (disable_thursday_utc and now.weekday() == 3)
                    g_rth = (not rth_enabled) or _rth_is_open(rth, now)

                    nth_ok = True
                    try:
                        _nl = now.tz_convert(tz_name)
                        _nth = locals().get("no_trade_hours", [9, 14, 15])
                        nth_ok = int(_nl.hour) not in set(int(x) for x in _nth)
                    valid = (
                        _isnum(o) and _isnum(c) and _isnum(body) and _isnum(volr) and _isnum(rsi) and _isnum(atr) and _isnum(vwap)
                        and (bear3 is not None) and (bull3 is not None)
                    )

                    body_ok = bool(valid and body >= BODY_MIN)
                    vol_ok  = bool(valid and volr >= VOL_REL_MIN)

                    dist = float("nan")
                    dist_ok = False
                    if valid:
                        dist = abs(c - vwap)
                        dist_ok = bool(dist >= (VWAP_K * atr))

                    long_ok = bool(
                        valid and dist_ok and (c > vwap) and (c > o) and (float(bear3) >= BEAR3_LONG) and (rsi <= RSI_LONG_MAX)
                    )
                    short_ok = bool(
                        valid and dist_ok and (c < vwap) and (c < o) and (float(bull3) >= BULL3_SHORT) and (rsi >= RSI_SHORT_MIN)
                    )

                    entry_ok = bool(g_thu and g_rth and nth_ok and valid and body_ok and vol_ok and (long_ok or short_ok))

                    bv = ("nan" if body != body else "{:.3f}".format(body))
                    vv = ("nan" if volr != volr else "{:.3f}".format(volr))
                    dv = ("nan" if dist != dist else "{:.2f}".format(dist))
                    av = ("nan" if atr  != atr  else "{:.2f}".format(atr))

                    log_line(
                        logfile,
                        "VIS | THU {thu} | RTH {rth} | VALID {val} | BODY {b}({bv}>={bmin}) | VOL {v}({vv}>={vmin}) | DIST {d}({dv}>={k}*{av}) | NTH {nth}".format(
                            thu=ok(g_thu), rth=ok(g_rth), val=ok(valid),
                            b=ok(body_ok), bv=bv, bmin="{:.2f}".format(BODY_MIN),
                            v=ok(vol_ok),  vv=vv, vmin="{:.2f}".format(VOL_REL_MIN),
                            d=ok(dist_ok), dv=dv, k="{:.2f}".format(VWAP_K), av=av,
                            nth=ok(nth_ok),
                        )
                    )
                    log_line(logfile, "LONG={L} SHORT={S} |".format(L=ok(long_ok), S=ok(short_ok)))
                    log_line(logfile, "ENTRY {E}".format(E=ok(entry_ok)))
            except Exception as _e:
                log_line(logfile, "VIS_ERR_ALWAYS: {}".format(repr(_e)))
            # VIS_ALWAYS_3LINES_GERMANY40_V1_END

            # VIS_ALWAYS_3LINES_SP500_V1_START
            try:
                # Solo SP500
                if str(locals().get("bot_id", "")) == "sp500_5m":
                    OK = "✅"
                    NO = "❌"
                    def ok(x): return OK if x else NO
                    import math

                    # MISMO patrón que Germany40: usa df ya calculado arriba
                    _row = df.iloc[-2] if len(df) >= 2 else df.iloc[-1]
                    _ts_raw = df.index[-2] if len(df) >= 2 else df.index[-1]

                    # TS robusto (evita int/naive -> tz_convert crash)
                    import pandas as pd
                    if isinstance(_ts_raw, (int, float)):
                        v = int(_ts_raw)
                        unit = "ms" if v > 10_000_000_000 else "s"
                        _ts_utc = pd.to_datetime(v, unit=unit, utc=True, errors="coerce")
                    else:
                        _ts_utc = pd.to_datetime(_ts_raw, utc=True, errors="coerce")

                    # si sale epoch/NaT por cualquier razón, usa now (solo para VIS)
                    if _ts_utc is pd.NaT or int(getattr(_ts_utc, "year", 0) or 0) < 2000:
                        _ts_utc = now

                                            # Guard final: evita 1970/1969 si el timestamp viene mal inferido
                        try:
                            if getattr(_ts_utc, 'year', 1970) < 2000:
                                _ts_utc = locals().get('sig_ts_utc') or pd.Timestamp.now(tz='UTC')
                            _ts_utc = locals().get('sig_ts_utc') or pd.Timestamp.now(tz='UTC')
_ts_ny = _ts_utc.tz_convert("America/New_York")

                    o = float(_row.get("open", float("nan")))
                    c = float(_row.get("close", float("nan")))
                    body = float(_row.get("body_ratio", float("nan")))
                    volr = float(_row.get("vol_rel", float("nan")))
                    rsi  = float(_row.get("rsi14", float("nan")))
                    atr  = float(_row.get("atr14", float("nan")))
                    rng  = float(_row.get("range", float("nan")))
                    bear3 = _row.get("bear_prev3", None)
                    bull3 = _row.get("bull_prev3", None)

                    # thresholds (misma spec que us500_5m_sma_spec.py)
                    BODY_MIN      = 0.70
                    VOL_REL_MIN   = 0.70
                    RSI_LONG_MAX  = 75.0
                    RSI_SHORT_MIN = 40.0
                    BEAR3_LONG    = 2
                    BULL3_SHORT   = 2

                    def _isnum(x):
                        try:
                            return (x == x) and (not math.isinf(x))
                            return False

                    # Gates según la VELA señal (como spec)
                    hhmm = (_ts_ny.hour, _ts_ny.minute)
                    g_rth = (hhmm >= (9,30)) and (hhmm <= (16,0))
                    g_thu = True if not disable_thursday_utc else (not (_ts_utc.weekday() == 3))  # no jueves UTC

                    valid = (
                        _isnum(o) and _isnum(c) and _isnum(body) and _isnum(volr) and _isnum(rsi) and _isnum(atr) and _isnum(rng)
                        and (bear3 is not None) and (bull3 is not None)
                        and (rng > 0)
                    )

                    body_ok = bool(valid and body >= BODY_MIN)
                    vol_ok  = bool(valid and volr >= VOL_REL_MIN)

                    long_ok  = bool(valid and (c > o) and (float(bear3) >= BEAR3_LONG) and (rsi < RSI_LONG_MAX))
                    short_ok = bool(valid and (c < o) and (float(bull3) >= BULL3_SHORT) and (rsi > RSI_SHORT_MIN))

                    entry_ok = bool(g_thu and g_rth and valid and body_ok and vol_ok and (long_ok or short_ok))

                    bv = ("nan" if body != body else "{:.3f}".format(body))
                    vv = ("nan" if volr != volr else "{:.3f}".format(volr))
                    rv = ("nan" if rsi  != rsi  else "{:.2f}".format(rsi))
                    av = ("nan" if atr  != atr  else "{:.2f}".format(atr))

                    # 3 líneas + ✅/❌ (igual que Germany40)

                    # --- SP500 extra VIS checks (RSI/A TR como condiciones de entrada) ---
                    # ATR válido
                    # RSI válido (mínimo: no NaN). Si tu cálculo de RSI marca inválido como NaN, esto lo refleja.
                    rsi_ok = bool(rsi == rsi)
                    # thresholds de tu spec (condiciones de entrada)
                    rsi_long_ok  = bool(rsi_ok and float(rsi) < 75.0)
                    # VIS_ALWAYS_RL_RS_AOK_FIX_V2 (evita KeyError('rL') y muestra checks RSI/ATR)
                    rsi_short_ok = bool(rsi_ok and float(rsi) > 40.0)
                    atr_ok = bool((atr == atr) and (float(atr) > 0.0))
                    rL = '✅' if rsi_long_ok else '❌'
                    rS = '✅' if rsi_short_ok else '❌'
                    aok = '✅' if atr_ok else '❌'
                    log_line(
                        logfile,
                        "VIS_SPEC | THU {thu} | RTH {rth} | VALID {val} | BODY {b}({bv}>={bmin}) | VOL {v}({vv}>={vmin}) | RSI {rv} L{rL}(<75) S{rS}(>40) | ATR {av} {aok}".format(
                            thu=ok(g_thu), rth=ok(g_rth), val=ok(valid),
                            b=ok(body_ok), bv=bv, bmin="{:.2f}".format(BODY_MIN),
                            v=ok(vol_ok),  vv=vv, vmin="{:.2f}".format(VOL_REL_MIN),
                            rv=rv, av=av, rL=rL, rS=rS, aok=aok,
                        )
                    )
                    log_line(logfile, "LONG={L} SHORT={S} |".format(L=ok(long_ok), S=ok(short_ok)))
                    log_line(logfile, "ENTRY {E}".format(E=ok(entry_ok)))
            except Exception as _e:
                log_line(logfile, "VIS_ERR_ALWAYS_SP500: {}".format(repr(_e)))

            # VIS_ALWAYS_3LINES_SP500_V1_END

            if sig is None:
                if once:
                    return
                time.sleep(poll)
                continue

            # evitar duplicar por la misma vela señal
            signal_bar_time = df.index[-2]
            # Fix: normalize signal_bar_time (df.index a veces viene como int epoch)
            try:
                if isinstance(signal_bar_time, (int, float)):
                    v = int(signal_bar_time)
                    unit = 'ms' if v > 10_000_000_000 else 's'
                    signal_bar_time = pd.to_datetime(v, unit=unit, utc=True, errors='coerce')
                else:
                    signal_bar_time = pd.to_datetime(signal_bar_time, utc=True, errors='coerce')
            if last_closed_time and (not pd.isna(signal_bar_time)) and signal_bar_time <= last_closed_time:
                if once:
                    return
                time.sleep(poll)
                continue

            last_closed_time = signal_bar_time
            try:
                st["last_closed_time"] = signal_bar_time.isoformat()
                st["last_closed_time"] = str(signal_bar_time)
            save_state(st)

            # =======================
            # 6) Sizing + 7) niveles
            # =======================
            # SP500 SPEC: entry en el CLOSE de la vela señal ([-2])
            if str(bot_id) in ("sp500_5m","sp500_5m_rth"):
                entry_price = float(df["close"].iloc[-2])      # close de la señal
                entry_time  = df.index[-2]                     # timestamp de la señal
            else:
                entry_price = float(df["open"].iloc[-1])       # comportamiento legacy
                entry_time  = df.index[-1]

            atr_signal = float(df["atr14"].iloc[-2])           # ATR de la vela señal

            # SP500_SPEC_FINAL_V1: override de spec en entrada (solo SP500)

            if str(bot_id) in ("sp500_5m","sp500_5m_rth"):
                # 6) Sizing (equity fija 25k, sin compounding)
                risk_cash = 500.0  # 0.02 * 25000
                atr_entry = float(atr_signal)
                if atr_entry <= 0:
                    # sin ATR válido no abrimos
                    if once: return
                    time.sleep(poll)
                    continue
                size = int(risk_cash // atr_entry)
                if size < 1:
                    size = 1
                # 7) SL/TP iniciales (ATR_entry constante)
                if str(sig.direction).upper() == "BUY":
                    sl_local = float(entry_price - 1.0 * atr_entry)
                    tp_local = float(entry_price + 3.0 * atr_entry)
                else:
                    sl_local = float(entry_price + 1.0 * atr_entry)
                    tp_local = float(entry_price - 3.0 * atr_entry)
                r_points = float(atr_entry)
                tp_r_multiple = 3.0
            else:
                init = strat.initial_risk(entry_price, atr_signal, sig, strat_params)
                r_points = float(init["r_points"])
                sl_local = float(init["sl_local"])
                tp_local = float(init["tp_local"])
                tp_r_multiple = float(init.get("tp_r_multiple", 3.0))
                size = calc_position_size(
                    bot_equity=bot_equity,
                    risk_pct=risk_pct,
                    r_points=r_points,
                    value_per_point_per_size=vpp,
                )
            log_line(logfile, f"SIGNAL {sig.direction} entry_open={entry_price:.2f} size={size} R={r_points:.2f} TP({tp_r_multiple}R)={tp_local:.2f}")

            # Enforce account justo antes de abrir posición (última barrera)
            client.login()
            client.ensure_account(account_id)
            try:
                sess_dbg = client.get_session() or {}
                cur_dbg = sess_dbg.get("currentAccountId") or sess_dbg.get("accountId")
                if account_id and str(cur_dbg) != str(account_id):
                    log_line(logfile, f"ACCOUNT_MISMATCH expected={account_id} got={cur_dbg} (aborting ENTRY)")
                    if once:
                        return
                    time.sleep(poll)
                    continue
            except Exception as _e:
                log_line(logfile, f"ACCOUNT check failed pre-ENTRY: {repr(_e)}")
                if once:
                    return
                time.sleep(poll)
                continue

            
            # Ensure session + correct account JUST-IN-TIME (antes de enviar orden real)
            client.login()
            client.ensure_account(account_id)
            try:
                sess_dbg = client.get_session() or {}
                cur_dbg = sess_dbg.get("currentAccountId") or sess_dbg.get("accountId")
                log_line(logfile, f"TRADE SESSION account_id={cur_dbg} expected={account_id}")
                if account_id and str(cur_dbg) != str(account_id):
                    log_line(logfile, f"ACCOUNT_MISMATCH expected={account_id} got={cur_dbg} (aborting trade)")
                    raise RuntimeError("ACCOUNT_MISMATCH")
            except Exception as _e:
                log_line(logfile, f"TRADE SESSION check failed: {repr(_e)}")
                raise

            resp = client.open_market(epic, sig.direction, size)
            email_event(email_enabled, bot_id, "TRADE_OPEN", {
                "epic": epic,
                "direction": sig.direction,
                "size": size,
                "open_resp": resp,
                "account_id": account_id,
            }, logfile)

            deal_ref = (resp or {}).get("dealReference") or (resp or {}).get("deal_reference")
            if not deal_ref:
                log_line(logfile, f"ENTRY ERROR no dealReference resp={str(resp)[:250]}")
                if once:
                    return
                time.sleep(poll)
                continue

            conf = client.confirm(str(deal_ref), timeout_sec=30) or {}
            deal_id = pick_position_dealid_from_confirm(conf)
            if not deal_id:
                log_line(logfile, f"ENTRY ERROR no dealId confirm={str(conf)[:250]}")
                if once:
                    return
                time.sleep(poll)
                continue

            planned_exit = entry_time + pd.Timedelta(minutes=exit_bars * bar_minutes)

            st["pos"] = {
                "deal_id": str(deal_id),
                "direction": sig.direction,
                "size": float(size),
                "entry_time_iso": entry_time.isoformat(),
                "entry_price_est": float(entry_price),
                "entry_price_api": (conf or {}).get("level"),
                "r_points": float(r_points),
                "sl_local": float(sl_local),
                "tp_local": float(tp_local),
                "planned_exit_iso": planned_exit.isoformat(),
                "trail_1r_done": False,
                "trail_2r_done": False,
                
                # --- SP500 SPEC extra state ---
                "atr_entry": float(atr_entry) if str(bot_id) == "sp500_5m" else None,
                "bars_since_entry": 0 if str(bot_id) == "sp500_5m" else None,
                "be_armed": False if str(bot_id) == "sp500_5m" else None,
                "max_fav": float(entry_price) if (str(bot_id) == "sp500_5m" and str(sig.direction).upper() == "BUY") else None,
                "min_fav": float(entry_price) if (str(bot_id) == "sp500_5m" and str(sig.direction).upper() == "SELL") else None,
                "meta": sig.meta,
            }
            save_state(st)

            # SP500_SPEC_FINAL_V1: state extra por trade (solo SP500)
            if str(bot_id) in ("sp500_5m","sp500_5m_rth"):
                st["pos"]["atr_entry"] = float(atr_signal)
                st["pos"]["be_armed"] = False
                st["pos"]["bars_since_entry"] = 0
                if str(sig.direction).upper() == "BUY":
                    st["pos"]["max_fav"] = float(entry_price)
                else:
                    st["pos"]["min_fav"] = float(entry_price)
                save_state(st)

            email_event(email_enabled, bot_id, "ENTRY_OPENED", {
                "deal_id": str(deal_id),
                "direction": sig.direction,
                "size": size,
                "entry_price": entry_price,
                "sl_local": sl_local,
                "tp_local": tp_local,
                "planned_exit": planned_exit.isoformat(),
            }, logfile)

            if once:
                return
            time.sleep(poll)

    finally:
        try:
            lock.release()
