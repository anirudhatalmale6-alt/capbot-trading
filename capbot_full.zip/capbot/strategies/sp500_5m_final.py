from __future__ import annotations

from dataclasses import dataclass
import math
import pandas as pd

# Estrategia FINAL SP500 5m (según spec del usuario)
# - SOLO velas cerradas: el engine debe evaluar sobre df.iloc[-2]
# - Filtros en vela señal i: RTH NY (incluye 16:00) y "no jueves UTC" SOLO si disable_thursday_utc=True
# - RSI(14): SMA14(up)/SMA14(down). Si down==0 => RSI inválido (NaN)
# - ATR(14): SMA14(TR)
# - vol_ma20 incluye volume[i] (sin shift)

@dataclass
class _Sig:
    direction: str        # "BUY" | "SELL"
    ts: pd.Timestamp      # timestamp vela señal (UTC)
    entry_price: float
    atr_entry: float


class SP500_5M_FINAL:
    name = "sp500_5m_final"

    def __init__(self, **params):
        self.params = params or {}

    @staticmethod
    def _ensure_time_index(df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        if isinstance(df.index, pd.DatetimeIndex):
            idx = df.index
            if idx.tz is None:
                df.index = idx.tz_localize("UTC")
            else:
                df.index = idx.tz_convert("UTC")
            return df

        if "time" in df.columns:
            t = pd.to_datetime(df["time"], utc=True, errors="coerce")
            if t.notna().any():
                df.index = t
                return df

        # último recurso: intenta convertir el index numérico (epoch s/ms)
        try:
            v = int(df.index[-1])
            unit = "ms" if v > 10**11 else "s"
            df.index = pd.to_datetime(df.index.astype("int64"), unit=unit, utc=True, errors="coerce")
        except Exception:
            raise ValueError("Need df['time'] or DatetimeIndex (UTC)")
        return df

    @staticmethod
    def _isnum(x) -> bool:
        try:
            return (x == x) and (not math.isinf(float(x)))
        except Exception:
            return False

    # =========================
    # 3) Indicadores (exactos)
    # =========================
    @staticmethod
    def enrich(df: pd.DataFrame, params: dict | None = None) -> pd.DataFrame:
        params = params or {}
        df = df.copy()

        # columnas mínimas
        for c in ("open","high","low","close","volume"):
            if c not in df.columns:
                raise ValueError(f"Missing column: {c}")

        df = SP500_5M_FINAL._ensure_time_index(df)

        o = df["open"].astype("float64")
        h = df["high"].astype("float64")
        l = df["low"].astype("float64")
        c = df["close"].astype("float64")
        v = df["volume"].astype("float64")

        # 3.1 body_ratio
        rng = (h - l)
        df["range"] = rng
        body = (c - o).abs() / rng.replace(0, pd.NA)
        body = body.where(rng > 0)  # si range<=0 => NaN
        df["body_ratio"] = body

        # 3.2 vol_rel (SMA20 incluye volume[i])
        vol_ma20 = v.rolling(20, min_periods=20).mean()
        df["vol_ma20"] = vol_ma20
        vol_rel = v / vol_ma20.replace(0, pd.NA)
        df["vol_rel"] = vol_rel

        # 3.3 RSI(14) con SMA14(up)/SMA14(down)
        delta = c.diff()
        up = delta.clip(lower=0)
        down = (-delta).clip(lower=0)
        up_sma = up.rolling(14, min_periods=14).mean()
        down_sma = down.rolling(14, min_periods=14).mean()
        # si down==0 => RSI inválido
        rs = up_sma / down_sma.replace(0, pd.NA)
        rsi = 100 - (100 / (1 + rs))
        rsi = rsi.where(down_sma != 0)
        df["rsi14"] = rsi

        # 3.4 ATR(14) SMA14(TR)
        prev_close = c.shift(1)
        tr = pd.concat([
            (h - l),
            (h - prev_close).abs(),
            (l - prev_close).abs(),
        ], axis=1).max(axis=1)
        atr = tr.rolling(14, min_periods=14).mean()
        df["tr"] = tr
        df["atr14"] = atr

        # 3.5 prev3 excluye vela señal
        bear = (c < o).astype("int64")
        bull = (c > o).astype("int64")
        df["bear_prev3"] = bear.shift(1).rolling(3, min_periods=3).sum()
        df["bull_prev3"] = bull.shift(1).rolling(3, min_periods=3).sum()

        return df

    # =========================
    # 4) Señal (vela i)
    # =========================
    @staticmethod
    def signal_on_row(df: pd.DataFrame, i: int, params: dict | None = None):
        params = params or {}
        disable_thursday_utc = bool(params.get("disable_thursday_utc", False))

        # thresholds de tu spec
        BODY_MIN = 0.70
        VOL_REL_MIN = 0.70
        RSI_LONG_MAX = 75.0
        RSI_SHORT_MIN = 40.0

        row = df.iloc[i]
        ts_utc = pd.Timestamp(df.index[i]).tz_convert("UTC")

        # 2) Session filters en vela señal i
        ts_ny = ts_utc.tz_convert("America/New_York")
        hhmm = (ts_ny.hour, ts_ny.minute)
        rth_ok = (hhmm >= (9, 30)) and (hhmm <= (16, 0))

        thu_ok = True if (not disable_thursday_utc) else (ts_utc.weekday() != 3)

        # 3) Validaciones
        o = float(row["open"]); c = float(row["close"]); h = float(row["high"]); l = float(row["low"])
        rng = float(row.get("range", h - l))
        body = float(row.get("body_ratio", float("nan")))
        vol_rel = float(row.get("vol_rel", float("nan")))
        rsi = float(row.get("rsi14", float("nan")))
        atr = float(row.get("atr14", float("nan")))
        bear3 = row.get("bear_prev3", None)
        bull3 = row.get("bull_prev3", None)

        valid = (
            SP500_5M_FINAL._isnum(o) and SP500_5M_FINAL._isnum(c) and SP500_5M_FINAL._isnum(h) and SP500_5M_FINAL._isnum(l)
            and SP500_5M_FINAL._isnum(rng) and rng > 0
            and SP500_5M_FINAL._isnum(body)
            and SP500_5M_FINAL._isnum(vol_rel)
            and SP500_5M_FINAL._isnum(rsi)
            and SP500_5M_FINAL._isnum(atr)
            and (bear3 is not None) and (bull3 is not None)
        )
        if not valid:
            return None

        if not (rth_ok and thu_ok):
            return None

        if not (body >= BODY_MIN and vol_rel >= VOL_REL_MIN):
            return None

        # 4) condiciones entrada
        long_ok = (c > o) and (float(bear3) >= 2) and (rsi < RSI_LONG_MAX)
        short_ok = (c < o) and (float(bull3) >= 2) and (rsi > RSI_SHORT_MIN)

        if long_ok:
            return _Sig(direction="BUY", ts=ts_utc, entry_price=c, atr_entry=atr)
        if short_ok:
            return _Sig(direction="SELL", ts=ts_utc, entry_price=c, atr_entry=atr)

        return None

    @staticmethod
    def signal(df: pd.DataFrame, params: dict | None = None):
        # engine debe pasar DF cerrado; si hay vela viva al final, evaluamos df.iloc[-2]
        params = params or {}
        df2 = SP500_5M_FINAL.enrich(df, params)

        if df2 is None or df2.empty or len(df2) < 3:
            return None

        i = -2
        return SP500_5M_FINAL.signal_on_row(df2, i, params)


# --- Added: enrich() shim for VIS/debug (matches spec) ---
import pandas as _pd
import numpy as _np

def _sp500_enrich(df: _pd.DataFrame, params=None) -> _pd.DataFrame:
    df = df.copy()

    # 3.1 Body ratio
    df["range"] = (df["high"] - df["low"]).astype(float)
    df.loc[df["range"] <= 0, "range"] = _np.nan
    df["body_ratio"] = (df["close"] - df["open"]).abs() / df["range"]

    # 3.2 Volumen relativo (SMA20 incluye volume[i], sin shift)
    df["vol_ma20"] = df["volume"].rolling(20, min_periods=20).mean()
    df["vol_rel"] = df["volume"] / df["vol_ma20"]
    df.loc[(df["vol_ma20"].isna()) | (df["vol_ma20"] == 0) | (df["volume"].isna()), "vol_rel"] = _np.nan

    # 3.3 RSI14 con SMA14(up/down). down==0 => inválido (NaN)
    delta = df["close"].diff()
    up = delta.clip(lower=0).rolling(14, min_periods=14).mean()
    down = (-delta.clip(upper=0)).rolling(14, min_periods=14).mean()
    rs = up / down
    rsi = 100 - (100 / (1 + rs))
    rsi = rsi.where(down != 0)
    df["rsi14"] = rsi

    # 3.4 ATR14 (SMA14 del TR)
    prev_close = df["close"].shift(1)
    tr = _pd.concat([
        (df["high"] - df["low"]).abs(),
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)
    df["atr14"] = tr.rolling(14, min_periods=14).mean()

    # 3.5 prev3 (excluye vela señal)
    bear = (df["close"] < df["open"]).astype(int)
    bull = (df["close"] > df["open"]).astype(int)
    df["bear_prev3"] = bear.shift(1).rolling(3, min_periods=3).sum()
    df["bull_prev3"] = bull.shift(1).rolling(3, min_periods=3).sum()

    return df

try:
    SP500_5M_FINAL.enrich = staticmethod(_sp500_enrich)
except Exception:
    pass
# --- end enrich shim ---
