import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict

@dataclass(frozen=True)
class BotConfig:
    raw: Dict[str, Any]

def _expand_env(v):
    if isinstance(v, str):
        m = re.fullmatch(r"\$\{([A-Z0-9_]+)\}", v.strip())
        if m:
            return os.environ.get(m.group(1), v)
    return v

def load_config(path: str) -> BotConfig:
    p = Path(path)
    raw = json.loads(p.read_text(encoding="utf-8"))
    acc = raw.get("account") or {}
    if "account_id" in acc:
        acc["account_id"] = _expand_env(acc["account_id"])
        raw["account"] = acc
    return BotConfig(raw=raw)
