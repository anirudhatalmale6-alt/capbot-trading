from typing import Any, Dict
from capbot.domain.logger import log_line

try:
    from email_notify import send_trade_email
except Exception:
    send_trade_email = None

def _send(enabled: bool, subject: str, body: str, logfile) -> None:
    if not enabled or not send_trade_email:
        return
    ok = False
    try:
        ok = bool(send_trade_email(subject, body))
    except Exception:
        ok = False
    log_line(logfile, f"EMAIL {'OK' if ok else 'SKIP/FAIL'} subject={subject}")

def email_startup(enabled: bool, bot_id: str, cfg: Dict[str, Any], logfile) -> None:
    _send(enabled, f"[{bot_id}] Startup OK", f"bot_id={bot_id}\nmarket={cfg.get('market')}\nstrategy={cfg.get('strategy',{}).get('module')}", logfile)

def email_event(enabled: bool, bot_id: str, event: str, data: Dict[str, Any], logfile) -> None:
    lines = [f"{k}: {v}" for k,v in (data or {}).items()]
    _send(enabled, f"[{bot_id}] {event}", "\n".join(lines), logfile)
