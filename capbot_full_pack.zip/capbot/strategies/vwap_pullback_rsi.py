from typing import Any, Dict, Optional
import pandas as pd
from capbot.data.indicators import rsi, atr, vwap_intraday
from capbot.domain.models import Signal

class VWAPPullbackRSI:
    name = "vwap_pullback_rsi"

    def enrich(self, df: pd.DataFrame, params: Dict[str, Any]) -> pd.DataFrame:
        vol_window = int(params.get("VOL_WINDOW", 20))
        rsi_period = int(params.get("RSI_PERIOD", 14))
        atr_period = int(params.get("ATR_PERIOD", 14))
        vwap_tz = params.get("VWAP_TZ", "Europe/Berlin")

        d = df.copy()
        d["range"] = (d["high"] - d["low"])
        d["body_ratio"] = (d["close"] - d["open"]).abs() / d["range"].replace(0, pd.NA)

        d["vol_ma"] = d["volume"].rolling(vol_window, min_periods=vol_window).mean()
        d["vol_rel"] = d["volume"] / d["vol_ma"].replace(0, pd.NA)

        d["bear"] = (d["close"] < d["open"]).astype(int)
        d["bull"] = (d["close"] > d["open"]).astype(int)
        d["bear_prev3"] = d["bear"].shift(1).rolling(3).sum()
        d["bull_prev3"] = d["bull"].shift(1).rolling(3).sum()

        d["rsi14"] = rsi(d["close"], rsi_period)
        d["atr14"] = atr(d, atr_period)
        d["vwap"] = vwap_intraday(d, vwap_tz)
        return d

    def signal_on_bar_close(self, df: pd.DataFrame, params: Dict[str, Any]) -> Optional[Signal]:
        if df.empty or len(df) < 50:
            return None
        last = df.iloc[-2]

        close_px = float(last["close"])
        open_px = float(last["open"])

        body_min = float(params.get("BODY_MIN", 0.7))
        vol_rel_min = float(params.get("VOL_REL_MIN", 0.7))

        rsi_long_max = float(params.get("RSI_LONG_MAX", 75))
        rsi_short_min = float(params.get("RSI_SHORT_MIN", 40))
        bear_prev3_long = int(params.get("BEAR_PREV3_LONG", 2))
        bull_prev3_short = int(params.get("BULL_PREV3_SHORT", 2))

        need = ["body_ratio","vol_rel","rsi14","atr14","vwap","bear_prev3","bull_prev3"]
        if any(pd.isna(last[k]) for k in need):
            return None

        br = float(last["body_ratio"])
        vr = float(last["vol_rel"])
        if br < body_min or vr < vol_rel_min:
            return None

        rsi_v = float(last["rsi14"])
        atr_v = float(last["atr14"])
        vwap_px = float(last["vwap"])
        bear3 = int(last["bear_prev3"])
        bull3 = int(last["bull_prev3"])

        cond_long = (close_px > vwap_px) and (bear3 >= bear_prev3_long) and (rsi_v <= rsi_long_max) and (close_px > open_px)
        cond_short = (close_px < vwap_px) and (bull3 >= bull_prev3_short) and (rsi_v >= rsi_short_min) and (close_px < open_px)

        meta = {
            "body_ratio": br, "vol_rel": vr, "rsi14": rsi_v, "atr14": atr_v, "vwap": vwap_px,
            "bear_prev3": bear3, "bull_prev3": bull3
        }

        if cond_long:
            return Signal(direction="BUY", entry_price_est=close_px, meta=meta)
        if cond_short:
            return Signal(direction="SELL", entry_price_est=close_px, meta=meta)
        return None

    def initial_trade_plan(self, signal: Signal, df: pd.DataFrame, params: Dict[str, Any]) -> Dict[str, Any]:
        sl_atr = float(params.get("SL_ATR", 1.0))
        tp_r_multiple = float(params.get("TP_R_MULTIPLE", 3.0))

        atr_v = float(signal.meta.get("atr14")) if signal.meta and "atr14" in signal.meta else float(df["atr14"].iloc[-2])
        entry = float(signal.entry_price_est)

        if signal.direction == "BUY":
            initial_sl = entry - sl_atr * atr_v
        else:
            initial_sl = entry + sl_atr * atr_v

        return {"initial_sl": float(initial_sl), "tp_r_multiple": tp_r_multiple}
