import math

def calc_position_size(bot_equity: float, risk_pct: float, r_points: float, value_per_point_per_size: float) -> float:
    if r_points is None or r_points <= 0 or math.isnan(r_points):
        return 1.0
    risk_cash = bot_equity * risk_pct
    denom = r_points * value_per_point_per_size
    if denom <= 0:
        return 1.0
    raw = risk_cash / denom
    return float(max(1.0, math.floor(raw)))
