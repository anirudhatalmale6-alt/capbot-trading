import os
from pathlib import Path

def load_secrets(path: str) -> None:
    p = Path(path).expanduser()
    if not p.exists():
        raise RuntimeError(
            f"No existe {p}. Crea el archivo con:\n"
            "CAPITAL_ENV=demo\nCAPITAL_API_KEY=...\nCAPITAL_IDENTIFIER=...\nCAPITAL_API_PASSWORD=...\n"
        )
    for raw in p.read_text(encoding="utf-8").splitlines():
        s = raw.strip()
        if not s or s.startswith("#") or "=" not in s:
            continue
        k, v = s.split("=", 1)
        os.environ[k.strip()] = v.strip()
