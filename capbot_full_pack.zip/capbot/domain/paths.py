from pathlib import Path

def bot_paths(bot_id: str):
    home = Path.home()
    safe = "".join(ch for ch in str(bot_id) if ch.isalnum() or ch in ("-","_")).strip() or "bot"
    state = home / f".capbot_state_{safe}.json"
    trades = home / f"capbot_trades_{safe}.csv"
    log = home / f"capbot_events_{safe}.log"
    lock = home / f".capbot_lock_{safe}.lock"
    return state, trades, log, lock
