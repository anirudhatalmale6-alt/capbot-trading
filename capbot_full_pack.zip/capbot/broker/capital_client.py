import json
import os
import time
from dataclasses import dataclass
from typing import Any, Dict, Optional

import requests

@dataclass
class Session:
    base: str
    cst: str
    xst: str

def base_url() -> str:
    env = os.environ.get("CAPITAL_ENV", "demo").lower()
    return "https://demo-api-capital.backend-capital.com" if env == "demo" else "https://api-capital.backend-capital.com"

def _headers(cst: str, xst: str) -> Dict[str, str]:
    return {
        "X-CAP-API-KEY": os.environ["CAPITAL_API_KEY"],
        "CST": cst,
        "X-SECURITY-TOKEN": xst,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

class CapitalClient:
    def __init__(self, timeout: int = 30):
        self.timeout = timeout
        self.s: Optional[Session] = None
        self.http = requests.Session()

    def login(self, retries: int = 8) -> Session:
        BASE = base_url()
        last_err = None
        for i in range(retries):
            try:
                r = self.http.post(
                    f"{BASE}/api/v1/session",
                    headers={
                        "X-CAP-API-KEY": os.environ["CAPITAL_API_KEY"],
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                    },
                    json={
                        "identifier": os.environ["CAPITAL_IDENTIFIER"],
                        "password": os.environ["CAPITAL_API_PASSWORD"],
                        "encryptedPassword": False,
                    },
                    timeout=self.timeout,
                )
                if r.status_code == 429:
                    time.sleep(min(60, 2**i))
                    continue
                r.raise_for_status()
                cst = r.headers.get("CST")
                xst = r.headers.get("X-SECURITY-TOKEN")
                if not cst or not xst:
                    raise RuntimeError("Login OK pero faltan CST/X-SECURITY-TOKEN")
                self.s = Session(base=BASE, cst=cst, xst=xst)
                return self.s
            except Exception as e:
                last_err = e
                time.sleep(min(60, 2**i))
        raise RuntimeError(f"Login failed. Last error: {repr(last_err)}")

    def _ensure(self) -> Session:
        if not self.s:
            return self.login()
        return self.s

    def request(self, method: str, path: str, *, params=None, json_body=None, data=None, retries: int = 6) -> requests.Response:
        sess = self._ensure()
        last_err = None
        for i in range(retries):
            r = None
            try:
                r = self.http.request(
                    method,
                    f"{sess.base}{path}",
                    headers=_headers(sess.cst, sess.xst),
                    params=params,
                    json=json_body,
                    data=data,
                    timeout=self.timeout,
                )
                if r.status_code == 401:
                    self.login()
                    sess = self._ensure()
                    continue
                if r.status_code == 429:
                    time.sleep(min(60, 2**i))
                    continue
                if r.status_code >= 500:
                    time.sleep(min(30, 2**i))
                    continue
                r.raise_for_status()
                return r
            except requests.exceptions.HTTPError as e:
                last_err = e
                if r is not None and 400 <= r.status_code < 500 and r.status_code not in (401, 429):
                    raise
                time.sleep(min(30, 2**i))
            except Exception as e:
                last_err = e
                time.sleep(min(30, 2**i))
        raise RuntimeError(f"Request failed {method} {path}. Last error: {repr(last_err)}")

    # account handling (best-effort)
    def get_session(self) -> Dict[str, Any]:
        r = self.request("GET", "/api/v1/session")
        return r.json()

    def select_account(self, account_id: str) -> bool:
        try:
            r = self.request("PUT", "/api/v1/session", json_body={"accountId": str(account_id)}, retries=3)
            return r.status_code in (200, 204)
        except Exception:
            return False

    def ensure_account(self, account_id: Optional[str]) -> None:
        if not account_id:
            return
        try:
            sess = self.get_session()
            cur = sess.get("currentAccountId") or sess.get("accountId")
            if str(cur) != str(account_id):
                self.select_account(str(account_id))
        except Exception:
            return

    # market / trading
    def get_prices(self, epic: str, resolution: str, max_points: int) -> Dict[str, Any]:
        r = self.request("GET", f"/api/v1/prices/{epic}", params={"resolution": resolution, "max": max_points})
        return r.json()

    def get_positions(self) -> Dict[str, Any]:
        return self.request("GET", "/api/v1/positions").json()

    def open_market(self, epic: str, direction: str, size: float) -> Dict[str, Any]:
        payload = {"epic": epic, "direction": direction, "size": float(size), "orderType": "MARKET"}
        return self.request("POST", "/api/v1/positions", data=json.dumps(payload)).json()

    def close_position(self, deal_id: str) -> Dict[str, Any]:
        r = self.request("DELETE", f"/api/v1/positions/{deal_id}")
        return r.json() if r.text else {}

    def confirm(self, deal_reference: str, timeout_sec: int = 30) -> Optional[Dict[str, Any]]:
        t0 = time.time()
        last = None
        while time.time() - t0 < timeout_sec:
            try:
                r = self.request("GET", f"/api/v1/confirms/{deal_reference}", retries=3)
                last = r.json()
                ds = (last.get("dealStatus") or "").upper()
                if ds in ("ACCEPTED", "REJECTED"):
                    return last
            except Exception:
                pass
            time.sleep(1)
        return last

def is_deal_open(positions_json: Dict[str, Any], deal_id: str) -> bool:
    for p in (positions_json or {}).get("positions", []) or []:
        pos = (p or {}).get("position") or {}
        if str(pos.get("dealId")) == str(deal_id):
            return True
    return False

def pick_position_dealid_from_confirm(conf: Dict[str, Any]) -> Optional[str]:
    aff = conf.get("affectedDeals") or []
    if isinstance(aff, list):
        for a in aff:
            if (a or {}).get("status") in ("OPENED", "PARTIALLY_OPENED"):
                did = (a or {}).get("dealId")
                if did:
                    return str(did)
    did = conf.get("dealId")
    return str(did) if did else None
