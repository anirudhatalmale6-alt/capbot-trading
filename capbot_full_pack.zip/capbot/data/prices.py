import pandas as pd
from typing import Any, Dict, Optional

def mid(px: Dict[str, Any]) -> Optional[float]:
    b = (px or {}).get("bid")
    a = (px or {}).get("ask")
    if b is not None and a is not None:
        return (float(b) + float(a)) / 2.0
    if b is not None:
        return float(b)
    if a is not None:
        return float(a)
    return None

def prices_to_df(j: Dict[str, Any]) -> pd.DataFrame:
    rows = []
    for p in (j.get("prices", []) or []):
        t = p.get("snapshotTimeUTC")
        if not t:
            continue
        o = mid(p.get("openPrice", {}) or {})
        h = mid(p.get("highPrice", {}) or {})
        l = mid(p.get("lowPrice", {}) or {})
        c = mid(p.get("closePrice", {}) or {})
        v = p.get("lastTradedVolume")
        if None in (o,h,l,c):
            continue
        rows.append({"time": t, "open": o, "high": h, "low": l, "close": c, "volume": v})
    df = pd.DataFrame(rows)
    if df.empty:
        return df
    df["time"] = pd.to_datetime(df["time"], utc=True, errors="coerce")
    df = df.dropna(subset=["time"])
    df = df.sort_values("time").drop_duplicates("time").reset_index(drop=True)
    df["volume"] = pd.to_numeric(df["volume"], errors="coerce").fillna(0.0)
    return df
